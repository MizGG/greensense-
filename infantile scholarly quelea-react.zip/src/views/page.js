import React from 'react'

import { Helmet } from 'react-helmet'

import './page.css'

const Page = (props) => {
  return (
    <div className="page-container">
      <Helmet>
        <title>Page - Infantile Scholarly Quelea</title>
        <meta property="og:title" content="Page - Infantile Scholarly Quelea" />
      </Helmet>
      <div className="page-mac-book-pro143">
        <div className="page-sidebar">
          <img
            alt="Bg1742"
            src="/external/bg1742-1sq-1100h.png"
            className="page-bg"
          />
          <div className="page-menu-sidebar">
            <div className="page-frame2">
              <div className="page-vuesaxboldelement3">
                <div className="page-vuesaxboldelement31">
                  <div className="page-element3">
                    <img
                      alt="Vector1742"
                      src="/external/vector1742-bjou.svg"
                      className="page-vector"
                    />
                    <img
                      alt="Vector1742"
                      src="/external/vector1742-nnk.svg"
                      className="page-vector01"
                    />
                    <img
                      alt="Vector1742"
                      src="/external/vector1742-yfal.svg"
                      className="page-vector02"
                    />
                    <img
                      alt="Vector1742"
                      src="/external/vector1742-ghfo.svg"
                      className="page-vector03"
                    />
                  </div>
                </div>
              </div>
              <span className="page-text">
                <span>Dashboard</span>
              </span>
            </div>
            <div className="page-frame4">
              <div className="page-iconvideotime">
                <img
                  alt="Vector1742"
                  src="/external/vector1742-pp4.svg"
                  className="page-vector04"
                />
                <img
                  alt="Vector1742"
                  src="/external/vector1742-a94o.svg"
                  className="page-vector05"
                />
                <img
                  alt="Vector1742"
                  src="/external/vector1742-577h.svg"
                  className="page-vector06"
                />
                <img
                  alt="Vector1742"
                  src="/external/vector1742-6rf.svg"
                  className="page-vector07"
                />
                <img
                  alt="Vector1742"
                  src="/external/vector1742-sjvb.svg"
                  className="page-vector08"
                />
                <img
                  alt="Vector1742"
                  src="/external/vector1742-nb6h.svg"
                  className="page-vector09"
                />
              </div>
              <span className="page-text02">
                <span>Recent</span>
              </span>
            </div>
            <div className="page-frame6">
              <div className="page-iconsave2">
                <img
                  alt="Vector1742"
                  src="/external/vector1742-01y8.svg"
                  className="page-vector10"
                />
                <img
                  alt="Vector1742"
                  src="/external/vector1742-zfj.svg"
                  className="page-vector11"
                />
                <img
                  alt="Vector1742"
                  src="/external/vector1742-eib8.svg"
                  className="page-vector12"
                />
              </div>
              <span className="page-text04">
                <span>Bookmark</span>
              </span>
            </div>
            <div className="page-frame8">
              <div className="page-help">
                <div className="page-help1">
                  <img
                    alt="Vector1742"
                    src="/external/vector1742-ymkh.svg"
                    className="page-vector13"
                  />
                  <div className="page-help2">
                    <img
                      alt="Vector1742"
                      src="/external/vector1742-o2ea.svg"
                      className="page-vector14"
                    />
                    <img
                      alt="Vector1742"
                      src="/external/vector1742-j9fw.svg"
                      className="page-vector15"
                    />
                  </div>
                </div>
              </div>
              <span className="page-text06">
                <span>Support</span>
              </span>
            </div>
            <div className="page-frame9">
              <div className="page-iconsetting2">
                <img
                  alt="Vector1742"
                  src="/external/vector1742-43i.svg"
                  className="page-vector16"
                />
                <img
                  alt="Vector1742"
                  src="/external/vector1742-0g6b.svg"
                  className="page-vector17"
                />
              </div>
              <span className="page-text08">
                <span>Setting</span>
              </span>
            </div>
          </div>
          <img
            alt="Rectangle3001742"
            src="/external/rectangle3001742-stjh-200w.png"
            className="page-rectangle300"
          />
          <div className="page-logo">
            <img
              alt="Logo1742"
              src="/external/logo1742-b4s3.svg"
              className="page-logo1"
            />
            <span className="page-text10">
              <span>Housipsm</span>
            </span>
          </div>
        </div>
        <div className="page-group76">
          <div className="page-group74">
            <div className="page-group7">
              <div className="page-group">
                <div className="page-rectangle23">
                  <div className="page-path">
                    <div className="page-group01">
                      <div className="page-group02">
                        <div className="page-path01">
                          <img
                            alt="Mask1756"
                            src="/external/mask1756-fro.svg"
                            className="page-mask"
                          />
                          <div className="page-object"></div>
                          <img
                            alt="MaskCopy1756"
                            src="/external/maskcopy1756-v5g.svg"
                            className="page-mask-copy"
                          />
                          <span className="page-text12">
                            <span>
                              Welcome Home! The air quality is good &amp; Fresh
                              you can go out today
                            </span>
                          </span>
                          <span className="page-text14">
                            <span>Hi Hamsavi!</span>
                          </span>
                          <img
                            alt="Path51756"
                            src="/external/path51756-wlr.svg"
                            className="page-path5"
                          />
                          <img
                            alt="Path5Copy1756"
                            src="/external/path5copy1756-0lrb.svg"
                            className="page-path-copy"
                          />
                          <img
                            alt="Path5Copy1756"
                            src="/external/path5copy1756-i6h5.svg"
                            className="page-path-copy1"
                          />
                          <img
                            alt="Path1756"
                            src="/external/path1756-ki3x.svg"
                            className="page-path02"
                          />
                          <div>
                            <div className="page-group03">
                              <img
                                alt="Path1756"
                                src="/external/path1756-6p3.svg"
                                className="page-path03"
                              />
                              <div className="page-group04">
                                <img
                                  alt="Path1756"
                                  src="/external/path1756-o63d6.svg"
                                  className="page-path04"
                                />
                                <img
                                  alt="Path1756"
                                  src="/external/path1756-3usb.svg"
                                  className="page-path05"
                                />
                                <img
                                  alt="Path1756"
                                  src="/external/path1756-exvx.svg"
                                  className="page-path06"
                                />
                              </div>
                            </div>
                            <div className="page-group-copy">
                              <img
                                alt="Path1756"
                                src="/external/path1756-xfb.svg"
                                className="page-path07"
                              />
                              <div className="page-group05">
                                <img
                                  alt="Path1756"
                                  src="/external/path1756-b5t.svg"
                                  className="page-path08"
                                />
                                <img
                                  alt="Path1756"
                                  src="/external/path1756-1i7e.svg"
                                  className="page-path09"
                                />
                                <img
                                  alt="Path1756"
                                  src="/external/path1756-o2ph.svg"
                                  className="page-path10"
                                />
                              </div>
                            </div>
                          </div>
                          <div>
                            <div>
                              <span className="page-text16">
                                <span>Outdoor temperature</span>
                              </span>
                              <div>
                                <span className="page-text18">
                                  <span>+16</span>
                                </span>
                                <span className="page-text20">C</span>
                                <img
                                  alt="Oval1756"
                                  src="/external/oval1756-zz1n-200h.png"
                                  className="page-oval"
                                />
                              </div>
                            </div>
                          </div>
                          <span className="page-text21">
                            <span>Fuzzy cloudy weather</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="page-character">
            <img
              alt="Oval1756"
              src="/external/oval1756-q98a-200h.png"
              className="page-oval01"
            />
            <div className="page-girl">
              <div className="page-group12 page-group12">
                <div className="page-group06">
                  <div className="page-group07">
                    <div className="page-group08">
                      <img
                        alt="Path1756"
                        src="/external/path1756-o6z5.svg"
                        className="page-path11"
                      />
                      <div className="page-group09">
                        <img
                          alt="Path1756"
                          src="/external/path1756-7pzi.svg"
                          className="page-path12"
                        />
                        <img
                          alt="Path1756"
                          src="/external/path1756-679g.svg"
                          className="page-path13"
                        />
                      </div>
                    </div>
                    <img
                      alt="Path1756"
                      src="/external/path1756-pjmr.svg"
                      className="page-path14"
                    />
                  </div>
                  <div className="page-group10">
                    <div className="page-group11">
                      <img
                        alt="Path1756"
                        src="/external/path1756-682.svg"
                        className="page-path15"
                      />
                      <div>
                        <img
                          alt="Path1756"
                          src="/external/path1756-ox6.svg"
                          className="page-path16"
                        />
                        <img
                          alt="Path1756"
                          src="/external/path1756-wine.svg"
                          className="page-path17"
                        />
                      </div>
                    </div>
                    <div className="page-group13 page-group13">
                      <img
                        alt="Path1756"
                        src="/external/path1756-tog.svg"
                        className="page-path18"
                      />
                      <img
                        alt="Path1756"
                        src="/external/path1756-rldq.svg"
                        className="page-path19"
                      />
                      <img
                        alt="Path1756"
                        src="/external/path1756-j4x.svg"
                        className="page-path20"
                      />
                    </div>
                  </div>
                </div>
                <div className="page-group14">
                  <div>
                    <img
                      alt="Oval1756"
                      src="/external/oval1756-ieap-200w.png"
                      className="page-oval02"
                    />
                    <img
                      alt="Oval1756"
                      src="/external/oval1756-cgf6-200h.png"
                      className="page-oval03"
                    />
                  </div>
                  <img
                    alt="Path1756"
                    src="/external/path1756-5i3nj.svg"
                    className="page-path21"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-11mc.svg"
                    className="page-path22"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-e3s9.svg"
                    className="page-path23"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-ry3.svg"
                    className="page-path24"
                  />
                  <div>
                    <img
                      alt="Path1756"
                      src="/external/path1756-cgmj.svg"
                      className="page-path25"
                    />
                    <img
                      alt="Oval1756"
                      src="/external/oval1756-4c9-200h.png"
                      className="page-oval04"
                    />
                    <img
                      alt="Path1756"
                      src="/external/path1756-ti0e.svg"
                      className="page-path26"
                    />
                  </div>
                  <img
                    alt="Path1756"
                    src="/external/path1756-c4xs.svg"
                    className="page-path27"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-e8w.svg"
                    className="page-path28"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-v92c.svg"
                    className="page-path29"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-8z99.svg"
                    className="page-path30"
                  />
                  <div className="page-group17 page-group17">
                    <img
                      alt="Oval1756"
                      src="/external/oval1756-58u-200h.png"
                      className="page-oval05"
                    />
                    <img
                      alt="Path1756"
                      src="/external/path1756-e0a.svg"
                      className="page-path31"
                    />
                  </div>
                </div>
                <div className="page-group18 page-group18">
                  <img
                    alt="Path1756"
                    src="/external/path1756-kj8k.svg"
                    className="page-path32"
                  />
                  <div className="page-group19">
                    <img
                      alt="Path1756"
                      src="/external/path1756-mf0q.svg"
                      className="page-path33"
                    />
                    <div className="page-group20 page-group20">
                      <div className="page-group21">
                        <img
                          alt="Oval1756"
                          src="/external/oval1756-p480g-200h.png"
                          className="page-oval06"
                        />
                        <img
                          alt="Path1756"
                          src="/external/path1756-duc.svg"
                          className="page-path34"
                        />
                        <img
                          alt="Path1756"
                          src="/external/path1756-vo1r.svg"
                          className="page-path35"
                        />
                      </div>
                      <img
                        alt="Path1756"
                        src="/external/path1756-vput.svg"
                        className="page-path36"
                      />
                    </div>
                    <div className="page-group22">
                      <img
                        alt="Path1756"
                        src="/external/path1756-slfb.svg"
                        className="page-path37"
                      />
                      <img
                        alt="Path1756"
                        src="/external/path1756-8999.svg"
                        className="page-path38"
                      />
                    </div>
                    <img
                      alt="Path1756"
                      src="/external/path1756-3csn.svg"
                      className="page-path39"
                    />
                  </div>
                  <div className="page-group23">
                    <img
                      alt="Path1756"
                      src="/external/path1756-dld.svg"
                      className="page-path40"
                    />
                    <img
                      alt="Path1756"
                      src="/external/path1756-spjm.svg"
                      className="page-path41"
                    />
                  </div>
                  <div className="page-group24">
                    <div className="page-group25">
                      <img
                        alt="Path1756"
                        src="/external/path1756-pwphc.svg"
                        className="page-path42"
                      />
                      <div className="page-group26">
                        <img
                          alt="Path1756"
                          src="/external/path1756-8bk.svg"
                          className="page-path43"
                        />
                        <img
                          alt="Path1756"
                          src="/external/path1756-n77a.svg"
                          className="page-path44"
                        />
                        <img
                          alt="Path1756"
                          src="/external/path1756-fyhh.svg"
                          className="page-path45"
                        />
                        <img
                          alt="Path1756"
                          src="/external/path1756-7rd6i.svg"
                          className="page-path46"
                        />
                      </div>
                    </div>
                    <img
                      alt="Path1756"
                      src="/external/path1756-fpbm.svg"
                      className="page-path47"
                    />
                  </div>
                </div>
              </div>
              <div className="page-group27">
                <div className="page-group28">
                  <div className="page-group29">
                    <img
                      alt="Oval1756"
                      src="/external/oval1756-3pv8-200h.png"
                      className="page-oval07"
                    />
                    <img
                      alt="Path1756"
                      src="/external/path1756-iwq7.svg"
                      className="page-path48"
                    />
                  </div>
                  <img
                    alt="Path1756"
                    src="/external/path1756-nkpe.svg"
                    className="page-path49"
                  />
                </div>
                <img
                  alt="Path1756"
                  src="/external/path1756-gjwj.svg"
                  className="page-path50"
                />
                <img
                  alt="Path1756"
                  src="/external/path1756-sag9.svg"
                  className="page-path51"
                />
                <img
                  alt="Path1756"
                  src="/external/path1756-dbzq.svg"
                  className="page-path52"
                />
              </div>
            </div>
            <div className="page-group30">
              <img
                alt="OvalCopy21756"
                src="/external/ovalcopy21756-6qvf-200h.png"
                className="page-oval-copy2"
              />
              <div className="page-dog">
                <img
                  alt="Path1756"
                  src="/external/path1756-l7s.svg"
                  className="page-path53"
                />
                <div className="page-group31">
                  <img
                    alt="Path1756"
                    src="/external/path1756-46tse.svg"
                    className="page-path54"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-c09.svg"
                    className="page-path55"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-704.svg"
                    className="page-path56"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-wnjk.svg"
                    className="page-path57"
                  />
                  <img
                    alt="OvalCopy81756"
                    src="/external/ovalcopy81756-tjfq-200w.png"
                    className="page-oval-copy8"
                  />
                  <img
                    alt="OvalCopy101756"
                    src="/external/ovalcopy101756-c7z-200w.png"
                    className="page-oval-copy10"
                  />
                  <img
                    alt="OvalCopy111756"
                    src="/external/ovalcopy111756-q6a8-200w.png"
                    className="page-oval-copy11"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-bwhm.svg"
                    className="page-path58"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-iywd.svg"
                    className="page-path59"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-ithb.svg"
                    className="page-path60"
                  />
                  <img
                    alt="Oval1756"
                    src="/external/oval1756-5656-200h.png"
                    className="page-oval08"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-u68o.svg"
                    className="page-path61"
                  />
                  <img
                    alt="Oval1756"
                    src="/external/oval1756-1vus-200h.png"
                    className="page-oval09"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-uv6.svg"
                    className="page-path62"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-izd9.svg"
                    className="page-path63"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-c8p.svg"
                    className="page-path64"
                  />
                  <img
                    alt="Path1756"
                    src="/external/path1756-e1e.svg"
                    className="page-path65"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <img
          alt="Group161756"
          src="/external/group161756-kxix.svg"
          className="page-group16 page-group16"
        />
        <div className="page-group49">
          <div className="page-group47">
            <div className="page-group46">
              <div className="page-group-copy6">
                <div className="page-group41">
                  <span className="page-text23">
                    <span>TV</span>
                  </span>
                  <div className="page-group40">
                    <div className="page-group15 page-group15">
                      <img
                        alt="OvalCopy31756"
                        src="/external/ovalcopy31756-km3o-200w.png"
                        className="page-oval-copy3"
                      />
                    </div>
                  </div>
                  <span className="page-text25">
                    <span>ON</span>
                  </span>
                  <div className="page-group39">
                    <img
                      alt="Oval1756"
                      src="/external/oval1756-yi26-200h.png"
                      className="page-oval10"
                    />
                    <div className="page-group34">
                      <img
                        alt="Shape1756"
                        src="/external/shape1756-ekx.svg"
                        className="page-shape"
                      />
                      <img
                        alt="ShapeCopy1756"
                        src="/external/shapecopy1756-04z.svg"
                        className="page-shape-copy"
                      />
                      <img
                        alt="Path1756"
                        src="/external/path1756-39sr.svg"
                        className="page-path66"
                      />
                      <img
                        alt="Path1756"
                        src="/external/path1756-pu4c.svg"
                        className="page-path67"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="page-group4-copy">
              <div className="page-group-copy61">
                <div className="page-group411">
                  <span className="page-text27">
                    <span>Router</span>
                  </span>
                  <div className="page-group401">
                    <div className="page-group151">
                      <img
                        alt="OvalCopy31756"
                        src="/external/ovalcopy31756-10l-200w.png"
                        className="page-oval-copy31"
                      />
                    </div>
                  </div>
                  <span className="page-text29">
                    <span>ON</span>
                  </span>
                  <div className="page-group391">
                    <img
                      alt="Oval1756"
                      src="/external/oval1756-dj0n-200h.png"
                      className="page-oval11"
                    />
                    <div className="page-nounwifi2986547">
                      <div className="page-group32">
                        <img
                          alt="Shape1756"
                          src="/external/shape1756-8ctp.svg"
                          className="page-shape1"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="page-group4-copy">
            <div className="page-group461">
              <div className="page-group-copy62">
                <div className="page-group412">
                  <span className="page-text31">
                    <span>Music</span>
                  </span>
                  <div className="page-group402">
                    <div className="page-group152">
                      <img
                        alt="OvalCopy31756"
                        src="/external/ovalcopy31756-m3uq-200w.png"
                        className="page-oval-copy32"
                      />
                    </div>
                  </div>
                  <span className="page-text33">
                    <span>ON</span>
                  </span>
                  <div className="page-group392">
                    <img
                      alt="Oval1756"
                      src="/external/oval1756-dbva-200h.png"
                      className="page-oval12"
                    />
                    <div className="page-noun-cd2130569">
                      <div className="page-group33">
                        <img
                          alt="Shape1756"
                          src="/external/shape1756-gqzu.svg"
                          className="page-shape2"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="page-group4-copy1">
              <div className="page-group-copy63">
                <div className="page-group413">
                  <span className="page-text35">
                    <span>Lamps</span>
                  </span>
                  <div className="page-group403">
                    <div className="page-group153">
                      <img
                        alt="OvalCopy31756"
                        src="/external/ovalcopy31756-v3fs-200w.png"
                        className="page-oval-copy33"
                      />
                    </div>
                  </div>
                  <span className="page-text37">
                    <span>ON</span>
                  </span>
                  <div className="page-group393">
                    <img
                      alt="Oval1756"
                      src="/external/oval1756-2rpg-200h.png"
                      className="page-oval13"
                    />
                    <img
                      alt="CombinedShape1756"
                      src="/external/combinedshape1756-sg3n.svg"
                      className="page-combined-shape"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <button className="page-button">
          <span className="page-text39">
            <span>+ Add Device</span>
          </span>
        </button>
        <div className="page-chips">
          <div className="page-frame12">
            <span className="page-text41">
              <span>Living Room</span>
            </span>
          </div>
          <div className="page-frame13">
            <span className="page-text43">
              <span>Kitchen</span>
            </span>
          </div>
          <div className="page-frame14">
            <span className="page-text45">
              <span>Bed Room</span>
            </span>
          </div>
          <div className="page-frame15">
            <span className="page-text47">
              <span>Movie Room</span>
            </span>
          </div>
          <div className="page-frame16">
            <span className="page-text49">
              <span>Game Room</span>
            </span>
          </div>
          <div className="page-frame18">
            <span className="page-text51">
              <span>+ Add</span>
            </span>
          </div>
        </div>
        <div className="page-header">
          <img
            alt="Rectangle2931757"
            src="/external/rectangle2931757-wxuk-1200w.png"
            className="page-rectangle293"
          />
          <div className="page-icon">
            <div className="page-iconnotification">
              <img
                alt="Vector1757"
                src="/external/vector1757-ow5.svg"
                className="page-vector18"
              />
              <img
                alt="Vector1757"
                src="/external/vector1757-hul.svg"
                className="page-vector19"
              />
            </div>
          </div>
          <div className="page-icon1"></div>
          <div className="page-user-account">
            <img
              alt="Avatar1757"
              src="/external/avatar1757-hvac-200h.png"
              className="page-avatar"
            />
            <div className="page-name">
              <span className="page-text53">
                <span>Hamsavi</span>
              </span>
            </div>
          </div>
          <div className="page-iconarrowdown">
            <img
              alt="Vector1757"
              src="/external/vector1757-1zng.svg"
              className="page-vector20"
            />
          </div>
          <span className="page-text55">
            <span>Dashboard</span>
          </span>
          <div className="page-searchbar">
            <div className="page-group78">
              <span className="page-text57">
                <span>Search type of keywords</span>
              </span>
            </div>
          </div>
          <div className="page-help3">
            <div className="page-help4">
              <img
                alt="Exclude1757"
                src="/external/exclude1757-agoa.svg"
                className="page-exclude"
              />
            </div>
          </div>
        </div>
        <img
          alt="Searchaltduotoneline1764"
          src="/external/searchaltduotoneline1764-uqy.svg"
          className="page-searchaltduotoneline"
        />
      </div>
      <div className="page-frame">
        <div className="page-buttonicon">
          <div className="page-iconchart">
            <img
              alt="Vector1757"
              src="/external/vector1757-3wj7b.svg"
              className="page-vector21"
            />
            <img
              alt="Vector1757"
              src="/external/vector1757-li0q.svg"
              className="page-vector22"
            />
            <img
              alt="Vector1757"
              src="/external/vector1757-x9xze.svg"
              className="page-vector23"
            />
            <img
              alt="Vector1757"
              src="/external/vector1757-s52c.svg"
              className="page-vector24"
            />
          </div>
        </div>
        <div className="page-buttonicon1">
          <div className="page-iconsetting4">
            <img
              alt="Vector1757"
              src="/external/vector1757-d7np.svg"
              className="page-vector25"
            />
            <img
              alt="Vector1757"
              src="/external/vector1757-jiys.svg"
              className="page-vector26"
            />
            <img
              alt="Vector1757"
              src="/external/vector1757-yyoc.svg"
              className="page-vector27"
            />
            <img
              alt="Vector1757"
              src="/external/vector1757-3s5a.svg"
              className="page-vector28"
            />
            <img
              alt="Vector1757"
              src="/external/vector1757-3bqc.svg"
              className="page-vector29"
            />
            <img
              alt="Vector1757"
              src="/external/vector1757-sh1.svg"
              className="page-vector30"
            />
          </div>
        </div>
        <span className="page-text59">
          <span>Usage Status</span>
        </span>
        <span className="page-text61">
          <span>35.02Kwh</span>
        </span>
        <span className="page-text63">
          <span>32h</span>
        </span>
        <img
          alt="Line81757"
          src="/external/line81757-67vd.svg"
          className="page-line8"
        />
        <div className="page-months">
          <span className="page-text65">
            <span>9:00</span>
          </span>
          <span className="page-text67">
            <span>10:00</span>
          </span>
          <span className="page-text69">
            <span>11:00</span>
          </span>
          <span className="page-text71">
            <span>12:00</span>
          </span>
          <span className="page-text73">
            <span>13:00</span>
          </span>
          <span className="page-text75">
            <span>14:00</span>
          </span>
          <span className="page-text77">
            <span>15:00</span>
          </span>
          <span className="page-text79">
            <span>16:00</span>
          </span>
          <span className="page-text81">
            <span>17:00</span>
          </span>
          <span className="page-text83">
            <span>18:00</span>
          </span>
        </div>
        <img
          alt="Rectangle3141757"
          src="/external/rectangle3141757-0htis-200w.png"
          className="page-rectangle314"
        />
        <img
          alt="Rectangle3121757"
          src="/external/rectangle3121757-v7hu-200w.png"
          className="page-rectangle312"
        />
        <img
          alt="Rectangle3131757"
          src="/external/rectangle3131757-updn-200w.png"
          className="page-rectangle313"
        />
        <img
          alt="Rectangle3151757"
          src="/external/rectangle3151757-dsj-200w.png"
          className="page-rectangle315"
        />
        <img
          alt="Rectangle3161757"
          src="/external/rectangle3161757-jfjb-200w.png"
          className="page-rectangle316"
        />
        <img
          alt="Rectangle3171757"
          src="/external/rectangle3171757-zi0e-200w.png"
          className="page-rectangle317"
        />
        <img
          alt="Rectangle3181757"
          src="/external/rectangle3181757-kngu-200w.png"
          className="page-rectangle318"
        />
        <img
          alt="Rectangle3191757"
          src="/external/rectangle3191757-nmfx-200w.png"
          className="page-rectangle319"
        />
        <img
          alt="Rectangle3201757"
          src="/external/rectangle3201757-w7g-200w.png"
          className="page-rectangle320"
        />
        <img
          alt="Rectangle3211757"
          src="/external/rectangle3211757-ib6x-200w.png"
          className="page-rectangle321"
        />
        <img
          alt="Rectangle3221757"
          src="/external/rectangle3221757-la8z-200w.png"
          className="page-rectangle322"
        />
        <div className="page-frame10">
          <span className="page-text85">
            <span>30kw</span>
          </span>
        </div>
        <button className="page-button1">
          <span className="page-text87">
            <span>Today</span>
          </span>
          <div className="page-iconarrowdown1">
            <img
              alt="Vector1757"
              src="/external/vector1757-z86n.svg"
              className="page-vector31"
            />
          </div>
        </button>
        <span className="page-text89">
          <span>Total spend</span>
        </span>
        <span className="page-text91">
          <span>
            Total hours
            <span
              dangerouslySetInnerHTML={{
                __html: ' ',
              }}
            />
          </span>
        </span>
      </div>
    </div>
  )
}

export default Page
