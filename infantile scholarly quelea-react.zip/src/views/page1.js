import React from 'react'

import { Helmet } from 'react-helmet'

import './page1.css'

const Page1 = (props) => {
  return (
    <div className="page1-container">
      <Helmet>
        <title>Page1 - Infantile Scholarly Quelea</title>
        <meta
          property="og:title"
          content="Page1 - Infantile Scholarly Quelea"
        />
      </Helmet>
      <div className="page1-mac-book-pro141">
        <div className="page1-sidebar">
          <img
            alt="Bg1601"
            src="/external/bg1601-yopg-1100h.png"
            className="page1-bg"
          />
          <div className="page1-menu-sidebar">
            <div className="page1-frame2">
              <div className="page1-vuesaxboldelement3">
                <div className="page1-vuesaxboldelement31">
                  <div className="page1-element3">
                    <img
                      alt="Vector1601"
                      src="/external/vector1601-0bpe.svg"
                      className="page1-vector"
                    />
                    <img
                      alt="Vector1601"
                      src="/external/vector1601-hfr.svg"
                      className="page1-vector01"
                    />
                    <img
                      alt="Vector1601"
                      src="/external/vector1601-n7mh.svg"
                      className="page1-vector02"
                    />
                    <img
                      alt="Vector1601"
                      src="/external/vector1601-lpo.svg"
                      className="page1-vector03"
                    />
                  </div>
                </div>
              </div>
              <span className="page1-text">
                <span>Dashboard</span>
              </span>
            </div>
            <div className="page1-frame4">
              <div className="page1-iconvideotime">
                <img
                  alt="Vector1601"
                  src="/external/vector1601-tvj.svg"
                  className="page1-vector04"
                />
                <img
                  alt="Vector1601"
                  src="/external/vector1601-o9e4.svg"
                  className="page1-vector05"
                />
                <img
                  alt="Vector1601"
                  src="/external/vector1601-0njj.svg"
                  className="page1-vector06"
                />
                <img
                  alt="Vector1601"
                  src="/external/vector1601-kjk.svg"
                  className="page1-vector07"
                />
                <img
                  alt="Vector1601"
                  src="/external/vector1601-ekc.svg"
                  className="page1-vector08"
                />
                <img
                  alt="Vector1601"
                  src="/external/vector1601-sz8p.svg"
                  className="page1-vector09"
                />
              </div>
              <span className="page1-text02">
                <span>Recent</span>
              </span>
            </div>
            <div className="page1-frame6">
              <div className="page1-iconsave2">
                <img
                  alt="Vector1601"
                  src="/external/vector1601-086q.svg"
                  className="page1-vector10"
                />
                <img
                  alt="Vector1601"
                  src="/external/vector1601-d0l.svg"
                  className="page1-vector11"
                />
                <img
                  alt="Vector1601"
                  src="/external/vector1601-hm0u.svg"
                  className="page1-vector12"
                />
              </div>
              <span className="page1-text04">
                <span>Bookmark</span>
              </span>
            </div>
            <div className="page1-frame8">
              <div className="page1-help">
                <div className="page1-help1">
                  <img
                    alt="Vector1601"
                    src="/external/vector1601-zvqn.svg"
                    className="page1-vector13"
                  />
                  <div className="page1-help2">
                    <img
                      alt="Vector1601"
                      src="/external/vector1601-cnr.svg"
                      className="page1-vector14"
                    />
                    <img
                      alt="Vector1601"
                      src="/external/vector1601-32qr.svg"
                      className="page1-vector15"
                    />
                  </div>
                </div>
              </div>
              <span className="page1-text06">
                <span>Support</span>
              </span>
            </div>
            <div className="page1-frame9">
              <div className="page1-iconsetting2">
                <img
                  alt="Vector1601"
                  src="/external/vector1601-w5wui.svg"
                  className="page1-vector16"
                />
                <img
                  alt="Vector1601"
                  src="/external/vector1601-hi8.svg"
                  className="page1-vector17"
                />
              </div>
              <span className="page1-text08">
                <span>Setting</span>
              </span>
            </div>
          </div>
          <img
            alt="Rectangle3001601"
            src="/external/rectangle3001601-62s-200w.png"
            className="page1-rectangle300"
          />
          <div className="page1-logo">
            <img
              alt="Logo1601"
              src="/external/logo1601-ybae.svg"
              className="page1-logo1"
            />
            <span className="page1-text10">
              <span>Housipsm</span>
            </span>
          </div>
        </div>
        <div className="page1-searchbar">
          <div className="page1-group78">
            <span className="page1-text12">
              <span>Search type of keywords</span>
            </span>
          </div>
          <img
            alt="Searchaltduotoneline1737"
            src="/external/searchaltduotoneline1737-n2v.svg"
            className="page1-searchaltduotoneline"
          />
        </div>
        <span className="page1-text14">
          <span>Notification</span>
        </span>
        <span className="page1-text16">
          <span>Lights will now reduce to 50% brightness</span>
        </span>
        <span className="page1-text18">
          <span>Fan automaticlly turned off .</span>
        </span>
        <span className="page1-text20">
          <span>Lights will now increase to 70% brightness</span>
        </span>
        <span className="page1-text22">
          <span>Wi-Fi connected</span>
        </span>
        <span className="page1-text24">
          <span>Bedroom speaker battery low 5% charge remaining</span>
        </span>
        <span className="page1-text26">
          <span>Today, 9:00PM</span>
        </span>
        <span className="page1-text28">
          <span>Today, 7:00PM</span>
        </span>
        <span className="page1-text30">
          <span>Today, 5:30PM</span>
        </span>
        <span className="page1-text32">
          <span>Today, 5:00PM</span>
        </span>
        <span className="page1-text34">
          <span>Today, 9:30AM</span>
        </span>
        <img
          alt="Rectangle2931732"
          src="/external/rectangle2931732-z5wc-1200w.png"
          className="page1-rectangle293"
        />
        <div className="page1-icon">
          <div className="page1-iconnotification">
            <img
              alt="Vector1732"
              src="/external/vector1732-ews.svg"
              className="page1-vector18"
            />
            <img
              alt="Vector1732"
              src="/external/vector1732-yd4v.svg"
              className="page1-vector19"
            />
          </div>
        </div>
        <img
          alt="Rectangle461732"
          src="/external/rectangle461732-cn1-200h.png"
          className="page1-rectangle46"
        />
        <div className="page1-help3">
          <img
            alt="Exclude1732"
            src="/external/exclude1732-7di.svg"
            className="page1-exclude"
          />
        </div>
        <div className="page1-user-account">
          <img
            alt="Avatar1732"
            src="/external/avatar1732-8xlb-200h.png"
            className="page1-avatar"
          />
          <div className="page1-name">
            <span className="page1-text36">
              <span>Hamsavi</span>
            </span>
          </div>
        </div>
        <div className="page1-iconarrowdown">
          <img
            alt="Vector1732"
            src="/external/vector1732-qwfj.svg"
            className="page1-vector20"
          />
        </div>
        <div className="page1-iconarrowdown1">
          <img
            alt="Vector1732"
            src="/external/vector1732-ku4f.svg"
            className="page1-vector21"
          />
        </div>
        <div className="page1-lampfill">
          <img
            alt="Subtract1732"
            src="/external/subtract1732-7nw.svg"
            className="page1-subtract"
          />
        </div>
        <div className="page1-phonefill">
          <img
            alt="Subtract1732"
            src="/external/subtract1732-tv2p.svg"
            className="page1-subtract1"
          />
        </div>
        <div className="page1-turbine">
          <img
            alt="Frame221735"
            src="/external/frame221735-jjls.svg"
            className="page1-frame22"
          />
          <img
            alt="Frame241735"
            src="/external/frame241735-zdlf.svg"
            className="page1-frame24"
          />
          <img
            alt="Frame211735"
            src="/external/frame211735-oy8e.svg"
            className="page1-frame21"
          />
          <img
            alt="Frame231735"
            src="/external/frame231735-8gab.svg"
            className="page1-frame23"
          />
          <img
            alt="Frame251735"
            src="/external/frame251735-offr.svg"
            className="page1-frame25"
          />
          <img
            alt="Frame201735"
            src="/external/frame201735-euh.svg"
            className="page1-frame20"
          />
        </div>
        <div className="page1-lampfill1">
          <img
            alt="SubtractI1735"
            src="/external/subtracti1735-2r3c.svg"
            className="page1-subtract2"
          />
        </div>
        <div className="page1-cpu">
          <img
            alt="Rectangle39651736"
            src="/external/rectangle39651736-7gml.svg"
            className="page1-rectangle3965"
          />
          <img
            alt="Rectangle39661736"
            src="/external/rectangle39661736-a7r-200h.png"
            className="page1-rectangle3966"
          />
          <div className="page1-group8627">
            <img
              alt="Vector1751736"
              src="/external/vector1751736-4fhf.svg"
              className="page1-vector175"
            />
            <img
              alt="Vector1761736"
              src="/external/vector1761736-w9ih.svg"
              className="page1-vector176"
            />
          </div>
          <div className="page1-group8629">
            <img
              alt="Vector1751736"
              src="/external/vector1751736-fhjq.svg"
              className="page1-vector1751"
            />
            <img
              alt="Vector1761736"
              src="/external/vector1761736-97b.svg"
              className="page1-vector1761"
            />
          </div>
          <div className="page1-group8628">
            <img
              alt="Vector1751736"
              src="/external/vector1751736-s2kf.svg"
              className="page1-vector1752"
            />
            <img
              alt="Vector1761736"
              src="/external/vector1761736-zjhe.svg"
              className="page1-vector1762"
            />
          </div>
          <div className="page1-group8630">
            <img
              alt="Vector1751736"
              src="/external/vector1751736-xjn.svg"
              className="page1-vector1753"
            />
            <img
              alt="Vector1761736"
              src="/external/vector1761736-9kp9.svg"
              className="page1-vector1763"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default Page1
