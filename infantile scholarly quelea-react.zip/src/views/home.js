import React from 'react'

import { Helmet } from 'react-helmet'

import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Infantile Scholarly Quelea</title>
        <meta property="og:title" content="Infantile Scholarly Quelea" />
      </Helmet>
      <div className="home-mac-book-pro142">
        <img
          alt="IMAGE1bca1b6ffd2e435f95f52338b8d1f8b211732"
          src="/external/image1bca1b6ffd2e435f95f52338b8d1f8b211732-mfa8-1100h.png"
          className="home-image1bca1b6ffd2e435f95f52338b8d1f8b21"
        />
        <span className="home-text">
          <span>EnergySense</span>
        </span>
        <span className="home-text02">
          <span>Welcome Back</span>
        </span>
        <div className="home-frame19">
          <div className="home-frame24"></div>
        </div>
        <div className="home-frame25">
          <span className="home-text04">
            <span>********</span>
          </span>
          <div className="home-frame23"></div>
        </div>
        <div className="home-frame22"></div>
        <div className="home-frame26">
          <span className="home-text06">
            <span>LOGIN</span>
          </span>
        </div>
        <span className="home-text08">
          <span>Email</span>
        </span>
        <span className="home-text10">
          <span>Password</span>
        </span>
      </div>
    </div>
  )
}

export default Home
